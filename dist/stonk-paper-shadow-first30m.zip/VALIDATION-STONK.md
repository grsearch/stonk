# Stonk 恢复原程序验收

- 模式：Stonk 专用，原主模拟 + 原 Shadow，实盘代码封锁。
- 策略默认值与原 dump-v5-publish 一致，冻结模型策略标识 4aa9d98cc8a3e538。
- 241 项测试全部通过：原有回归测试，以及 Stonk 程序识别、非 SOL 精度、费用、估值、真实 Shadow 工作线程、原过滤响应、模拟买卖、状态报价与到期删失。
- 执行命令：node --test --test-isolation=none helius/test/*.test.js（Node 24.19.0；此环境不允许测试子进程，故使用同进程测试模式）。
- 原完整 Dashboard 页面与 /api/status 返回 HTTP 200。
- npm 按锁文件安装，禁用依赖安装脚本；可选 bigint 本地扩展未加载，测试使用纯 JavaScript 实现。
- 未配置真实 Helius 密钥。当前证明本地功能与离线集成，不证明在线迁移、行情完整性或报价资产覆盖率。
- Linux 安装与 COS 实际上传未在此 Windows 环境执行。

## 2026-09-12 复核

- 修复 Shadow 请求取消信号传递，并在异步估值完成后重新校验 3 秒报价期限。
- 交易处理失败时标记观测中断，避免 Shadow 将缺失行情视为连续覆盖。
- 补齐 CPMM 本币地址身份校验，增加 4 项回归测试。
- 完整测试 241/241 通过；Dashboard 页面及状态接口 HTTP 200。
- 未配置 Helius 时启动明确失败并返回退出码 1；本机没有持续运行在线监控。

## 2026-09-14 对齐指定参考目录

- 参考提交 404d67d；保留 Stonk/CPMM 适配与前轮修复。
- 同步新池 50 SOL 等值储备关闭规则、Shadow 早期失败对照、归档训练及持仓行情修正。
- 本轮完整测试 274/274 通过，含 Stonk 平台排他性、股票代币储备换算后的门槛、退出订阅及 30 分钟截止。
- Dashboard 页面与 /api/status 均返回 HTTP 200；未执行线上行情或 Linux 部署验证。

## 2026-09-15 服务器零交易修复

- 实际部署原先的 4847 条已解析交易全部被账户／估值适配拒绝；SCHH、ANTHROPIC 的主要可复现原因是报价 mint 扩展不受支持，并非 Raydium 没有估值池。
- 服务器自己的 Helius 成功查询 SCHH、ANTHROPIC 及第三种报价资产的 Raydium 估值。用实际公开 mint 账户新增回归样本；暂停和有效转账钩子继续拒绝，未开放本币扩展限制。
- 历史发现改用成功交易批量接口并持久化分页，实时迁移订阅增加 LaunchLab + CPMM 条件。为原本无具体原因的错误添加诊断及看板覆盖警告。
- 本地 Node 24 与服务器 Node 22.23.2 各 279 项测试通过。服务器独立目录用真实 Helius 验证当前账户解析、Raydium 估值和批量历史接口。
- 2026-09-15 08:31（北京时间）部署，原文件及状态备份在 `/opt/stonk-monitor/backups/repair-20260915T003119Z`。仅重启 Stonk 主程序和看板，实盘保持关闭。
- 历史池只用于只读账户诊断，没有重设运行中池子的毕业 AGE，没有补造历史模拟交易。尚不能据此承诺有新模拟成交或策略收益。

- 补充修正 CLMM 深度：价格仍取 sqrtPrice，深度取虚拟储备与金库余额扣除协议／基金费用后的较小值。防止小池依靠虚拟储备通过 100 SOL 估值门槛。
- 实时日志定位到 getBlockTime 的 RPC -32004；增加同 slot、同签名、成功确认交易的时间后备查询，失败时继续标记覆盖中断，绝不使用本机时间伪造 AGE。
- 最终本机与服务器完整测试均为 280/280 通过。后续备份：`/opt/stonk-monitor/backups/repair-depth-20260915T003837Z` 和 `/opt/stonk-monitor/backups/repair-time-20260915T004107Z`。

## 2026-09-15 策略参数更新

- 主模拟和未开启实盘的配置统一：砸单至少 7 SOL，同币亏损后冷却 60 秒，持仓 20 秒触发超时退出；Shadow 冷却对照同步。主模拟使用其现有毛盈亏口径判断亏损，实盘配置使用确认净亏损口径。
- 实盘继续强制关闭；Raydium 和毕业 30 分钟限制保持。旧模型策略标识不兼容，因此评分不可用，Shadow 仍继续采样。
- 本机和服务器 282/282 测试通过，覆盖主模拟亏损冷却、重建引擎后的状态保留、20 秒超时及未开启实盘的阈值。
- 服务器配置和原文件备份：`/opt/stonk-monitor/backups/strategy-20260915T005936Z`。

## 2026-09-15 Raydium 实盘启用

- 完成独立执行器、回执核对及真实持仓到期退出。模拟/实盘使用不同账本，实盘默认每笔 0.1 SOL，需显式 STONK_LIVE_ENABLED=true。
- 288/288 测试在本机 Node 24 和服务器 Node 22 通过，包括路由金额/最低输出/目的账户/非 Raydium 指令拒绝、回执身份、净亏损冷却和到期保留真实持仓。
- SOL 直接 CPMM 池 DREQ7fyveGL7dXxB7EsjgSDmRNceuD5W7J4hUgznZbFM、经 AMC 中转的 CPMM 池 4ZnqNTaxFXTSn5ZtFEr32THEtAPG3NoqvqQC4YBnkb8k 均通过完整往返链上模拟；买入模拟约 0.6 秒，非实际成交速度。
- 验证准备仅创建两个空 ATA（无买卖），交易 5woQHZwuxsqNTaU4hiT4uj3JwRFTLEV2GE7Hxkrwfmabdu8ZHQ4dwxxnn6gvsLz8vcEjoxX5sBFKwk3oyS9x7CNU 已确认。
- 北京时间 2026-09-15 10:49 启用实盘，备份目录 /opt/stonk-monitor/backups/live-20260915T024925Z。通过模拟不保证未来流动性、发行者权限、报价可用性或每次退出成功；失败持仓持续保留。

- 上线后另修复 Helius -32015：毕业历史和 JSON 行情读取接受版本 1，实际发送仍为 V0。读取格式已用真实响应核对；本机和服务器最终 289/289 测试通过。备份 /opt/stonk-monitor/backups/json-v1-20260915T025538Z。
