# Stonk 恢复原程序验收

- 模式：Stonk 专用，原主模拟 + 原 Shadow，实盘代码封锁。
- 策略默认值与原 dump-v5-publish 一致，冻结模型策略标识 4aa9d98cc8a3e538。
- 241 项测试全部通过：原有回归测试，以及 Stonk 程序识别、非 SOL 精度、费用、估值、真实 Shadow 工作线程、原过滤响应、模拟买卖、状态报价与到期删失。
- 执行命令：node --test --test-isolation=none helius/test/*.test.js（Node 24.19.0；此环境不允许测试子进程，故使用同进程测试模式）。
- 原完整 Dashboard 页面与 /api/status 返回 HTTP 200。
- npm 按锁文件安装，禁用依赖安装脚本；可选 bigint 本地扩展未加载，测试使用纯 JavaScript 实现。
- 未配置真实 Helius 密钥。当前证明本地功能与离线集成，不证明在线迁移、行情完整性或报价资产覆盖率。
- Linux 安装与 COS 实际上传未在此 Windows 环境执行。

## 2026-09-12 复核

- 修复 Shadow 请求取消信号传递，并在异步估值完成后重新校验 3 秒报价期限。
- 交易处理失败时标记观测中断，避免 Shadow 将缺失行情视为连续覆盖。
- 补齐 CPMM 本币地址身份校验，增加 4 项回归测试。
- 完整测试 241/241 通过；Dashboard 页面及状态接口 HTTP 200。
- 未配置 Helius 时启动明确失败并返回退出码 1；本机没有持续运行在线监控。
